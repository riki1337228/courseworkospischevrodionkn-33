﻿#pragma once

namespace CourseWork {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Media;

	/// <summary>
	/// Сводка для Dictionary
	/// </summary>
	public ref class Dictionary : public System::Windows::Forms::Form
	{
	public:
		Dictionary(Form^ form1)
		{
			InitializeComponent();
			//
			//TODO: добавьте код конструктора
			//
			this->form1 = form1;
		}

	protected:
		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		~Dictionary()
		{
			if (components)
			{
				delete components;
			}
		}
	private:
		Form^ form1;

	private: System::Windows::Forms::Button^ playSoundButton;
	private: System::Media::SoundPlayer^ player;
	private: System::Media::SoundPlayer^ player1;
	private: System::Media::SoundPlayer^ player2;
	private: System::Media::SoundPlayer^ player3;
	private: System::Media::SoundPlayer^ player4;
	private: System::Media::SoundPlayer^ player5;
	private: System::Media::SoundPlayer^ player6;
	private: System::Media::SoundPlayer^ player7;
	private: System::Media::SoundPlayer^ player8;
	private: System::Media::SoundPlayer^ player9;
	private: System::Media::SoundPlayer^ player10;
	private: System::Media::SoundPlayer^ player11;
	private: System::Media::SoundPlayer^ player12;
	private: System::Media::SoundPlayer^ player13;
	private: System::Media::SoundPlayer^ player14;
	private: System::Media::SoundPlayer^ player15;
	private: System::Media::SoundPlayer^ player16;
	private: System::Media::SoundPlayer^ player17;

	private: System::Windows::Forms::Button^ button5;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Button^ button6;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::Button^ button7;
	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::Button^ button8;
	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::Button^ button9;
	private: System::Windows::Forms::Label^ label10;
	private: System::Windows::Forms::Button^ button10;
	private: System::Windows::Forms::Label^ label11;
	private: System::Windows::Forms::Button^ button11;
	private: System::Windows::Forms::Label^ label12;
	private: System::Windows::Forms::Button^ button12;
	private: System::Windows::Forms::Label^ label13;
	private: System::Windows::Forms::Button^ button13;
	private: System::Windows::Forms::Label^ label14;
	private: System::Windows::Forms::Button^ button14;
	private: System::Windows::Forms::Label^ label15;
	private: System::Windows::Forms::Button^ button15;
	private: System::Windows::Forms::Label^ label16;
	private: System::Windows::Forms::Button^ button16;
	private: System::Windows::Forms::Label^ label17;
	private: System::Windows::Forms::Button^ button17;
	private: System::Windows::Forms::Label^ label18;
	private: System::Windows::Forms::Button^ button18;
	private: System::Windows::Forms::Label^ label19;
	private: System::Windows::Forms::Button^ button19;
	private: System::Windows::Forms::PictureBox^ pictureBox15;
	private: System::Windows::Forms::PictureBox^ pictureBox14;
	private: System::Windows::Forms::PictureBox^ pictureBox13;
	private: System::Windows::Forms::PictureBox^ pictureBox11;
	private: System::Windows::Forms::PictureBox^ pictureBox10;
	private: System::Windows::Forms::PictureBox^ pictureBox9;
	private: System::Windows::Forms::PictureBox^ pictureBox6;
	private: System::Windows::Forms::PictureBox^ pictureBox5;
	private: System::Windows::Forms::PictureBox^ pictureBox8;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::PictureBox^ pictureBox2;














	private: System::ComponentModel::IContainer^ components;

	private:
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Dictionary::typeid));
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->playSoundButton = (gcnew System::Windows::Forms::Button());
			this->player = (gcnew System::Media::SoundPlayer());
			this->player1 = (gcnew System::Media::SoundPlayer());
			this->player2 = (gcnew System::Media::SoundPlayer());
			this->player3 = (gcnew System::Media::SoundPlayer());
			this->player4 = (gcnew System::Media::SoundPlayer());
			this->player5 = (gcnew System::Media::SoundPlayer());
			this->player6 = (gcnew System::Media::SoundPlayer());
			this->player7 = (gcnew System::Media::SoundPlayer());
			this->player8 = (gcnew System::Media::SoundPlayer());
			this->player9 = (gcnew System::Media::SoundPlayer());
			this->player10 = (gcnew System::Media::SoundPlayer());
			this->player11 = (gcnew System::Media::SoundPlayer());
			this->player12 = (gcnew System::Media::SoundPlayer());
			this->player13 = (gcnew System::Media::SoundPlayer());
			this->player14 = (gcnew System::Media::SoundPlayer());
			this->player15 = (gcnew System::Media::SoundPlayer());
			this->player16 = (gcnew System::Media::SoundPlayer());
			this->player17 = (gcnew System::Media::SoundPlayer());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->button10 = (gcnew System::Windows::Forms::Button());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->button11 = (gcnew System::Windows::Forms::Button());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->button12 = (gcnew System::Windows::Forms::Button());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->button13 = (gcnew System::Windows::Forms::Button());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->button14 = (gcnew System::Windows::Forms::Button());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->button15 = (gcnew System::Windows::Forms::Button());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->button16 = (gcnew System::Windows::Forms::Button());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->button17 = (gcnew System::Windows::Forms::Button());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->button18 = (gcnew System::Windows::Forms::Button());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->button19 = (gcnew System::Windows::Forms::Button());
			this->pictureBox15 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox14 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox13 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox11 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox10 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox9 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox6 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox5 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox8 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox15))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox14))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox13))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox11))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox10))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox9))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox6))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox5))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox8))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->BeginInit();
			this->SuspendLayout();
			// 
			// button5
			// 
			this->button5->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button5.BackgroundImage")));
			this->button5->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button5->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button5->FlatAppearance->BorderSize = 0;
			this->button5->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button5->FlatAppearance->MouseOverBackColor = System::Drawing::Color::White;
			this->button5->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button5->Location = System::Drawing::Point(1518, 12);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(54, 38);
			this->button5->TabIndex = 3;
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &Dictionary::button5_Click);
			// 
			// button1
			// 
			this->button1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button1.BackgroundImage")));
			this->button1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button1->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button1->FlatAppearance->BorderSize = 0;
			this->button1->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button1->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->Location = System::Drawing::Point(12, 12);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(39, 38);
			this->button1->TabIndex = 4;
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Dictionary::button1_Click_1);
			// 
			// playSoundButton
			// 
			this->playSoundButton->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"playSoundButton.BackgroundImage")));
			this->playSoundButton->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->playSoundButton->Cursor = System::Windows::Forms::Cursors::Hand;
			this->playSoundButton->FlatAppearance->BorderSize = 0;
			this->playSoundButton->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->playSoundButton->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->playSoundButton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->playSoundButton->Location = System::Drawing::Point(503, 166);
			this->playSoundButton->Name = L"playSoundButton";
			this->playSoundButton->Size = System::Drawing::Size(101, 32);
			this->playSoundButton->TabIndex = 0;
			this->playSoundButton->UseVisualStyleBackColor = true;
			this->playSoundButton->Click += gcnew System::EventHandler(this, &Dictionary::playSoundButton_Click);
			// 
			// player
			// 
			this->player->LoadTimeout = 5;
			this->player->SoundLocation = L"dimension.wav";
			this->player->Stream = nullptr;
			this->player->Tag = nullptr;
			// 
			// player1
			// 
			this->player1->LoadTimeout = 5;
			this->player1->SoundLocation = L"diameter.wav";
			this->player1->Stream = nullptr;
			this->player1->Tag = nullptr;
			// 
			// player2
			// 
			this->player2->LoadTimeout = 5;
			this->player2->SoundLocation = L"successor.wav";
			this->player2->Stream = nullptr;
			this->player2->Tag = nullptr;
			// 
			// player3
			// 
			this->player3->LoadTimeout = 5;
			this->player3->SoundLocation = L"density.wav";
			this->player3->Stream = nullptr;
			this->player3->Tag = nullptr;
			// 
			// player4
			// 
			this->player4->LoadTimeout = 5;
			this->player4->SoundLocation = L"occupy.wav";
			this->player4->Stream = nullptr;
			this->player4->Tag = nullptr;
			// 
			// player5
			// 
			this->player5->LoadTimeout = 5;
			this->player5->SoundLocation = L"therefore.wav";
			this->player5->Stream = nullptr;
			this->player5->Tag = nullptr;
			// 
			// player6
			// 
			this->player6->LoadTimeout = 5;
			this->player6->SoundLocation = L"furthermore.wav";
			this->player6->Stream = nullptr;
			this->player6->Tag = nullptr;
			// 
			// player7
			// 
			this->player7->LoadTimeout = 5;
			this->player7->SoundLocation = L"recordable.wav";
			this->player7->Stream = nullptr;
			this->player7->Tag = nullptr;
			// 
			// player8
			// 
			this->player8->LoadTimeout = 5;
			this->player8->SoundLocation = L"duplicate.wav";
			this->player8->Stream = nullptr;
			this->player8->Tag = nullptr;
			// 
			// player9
			// 
			this->player9->LoadTimeout = 5;
			this->player9->SoundLocation = L"rewritable.wav";
			this->player9->Stream = nullptr;
			this->player9->Tag = nullptr;
			// 
			// player10
			// 
			this->player10->LoadTimeout = 5;
			this->player10->SoundLocation = L"hence.wav";
			this->player10->Stream = nullptr;
			this->player10->Tag = nullptr;
			// 
			// player11
			// 
			this->player11->LoadTimeout = 5;
			this->player11->SoundLocation = L"beam.wav";
			this->player11->Stream = nullptr;
			this->player11->Tag = nullptr;
			// 
			// player12
			// 
			this->player12->LoadTimeout = 5;
			this->player12->SoundLocation = L"resemble.wav";
			this->player12->Stream = nullptr;
			this->player12->Tag = nullptr;
			// 
			// player13
			// 
			this->player13->LoadTimeout = 5;
			this->player13->SoundLocation = L"stable.wav";
			this->player13->Stream = nullptr;
			this->player13->Tag = nullptr;
			// 
			// player14
			// 
			this->player14->LoadTimeout = 5;
			this->player14->SoundLocation = L"whereas.wav";
			this->player14->Stream = nullptr;
			this->player14->Tag = nullptr;
			// 
			// player15
			// 
			this->player15->LoadTimeout = 5;
			this->player15->SoundLocation = L"affordable.wav";
			this->player15->Stream = nullptr;
			this->player15->Tag = nullptr;
			// 
			// player16
			// 
			this->player16->LoadTimeout = 5;
			this->player16->SoundLocation = L"erase.wav";
			this->player16->Stream = nullptr;
			this->player16->Tag = nullptr;
			// 
			// player17
			// 
			this->player17->LoadTimeout = 5;
			this->player17->SoundLocation = L"encode.wav";
			this->player17->Stream = nullptr;
			this->player17->Tag = nullptr;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label1->Location = System::Drawing::Point(75, 161);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(460, 37);
			this->label1->TabIndex = 5;
			this->label1->Text = L"dimension - [ˌdɪˈmen.ʃən] - вимір";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::Transparent;
			this->label2->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label2->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 69.75F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label2->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label2->Location = System::Drawing::Point(532, -8);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(504, 124);
			this->label2->TabIndex = 37;
			this->label2->Text = L"Dictionary";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label3->Location = System::Drawing::Point(75, 233);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(485, 37);
			this->label3->TabIndex = 39;
			this->label3->Text = L"diameter - [daɪˈæm.ɪ.tər] - діаметр";
			// 
			// button2
			// 
			this->button2->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button2.BackgroundImage")));
			this->button2->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button2->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button2->FlatAppearance->BorderSize = 0;
			this->button2->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button2->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button2->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button2->Location = System::Drawing::Point(527, 238);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(101, 32);
			this->button2->TabIndex = 38;
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Dictionary::button2_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label4->Location = System::Drawing::Point(75, 307);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(489, 37);
			this->label4->TabIndex = 41;
			this->label4->Text = L"successor - [səkˈses.ər] - наступник";
			// 
			// button3
			// 
			this->button3->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button3.BackgroundImage")));
			this->button3->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button3->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button3->FlatAppearance->BorderSize = 0;
			this->button3->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button3->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button3->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button3->Location = System::Drawing::Point(530, 312);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(101, 32);
			this->button3->TabIndex = 40;
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Dictionary::button3_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label5->Location = System::Drawing::Point(75, 527);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(397, 37);
			this->label5->TabIndex = 47;
			this->label5->Text = L"therefore - [ˈðeə.fɔːr] - тому";
			// 
			// button4
			// 
			this->button4->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button4.BackgroundImage")));
			this->button4->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button4->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button4->FlatAppearance->BorderSize = 0;
			this->button4->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button4->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button4->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button4->Location = System::Drawing::Point(439, 532);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(101, 32);
			this->button4->TabIndex = 46;
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Dictionary::button4_Click);
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label6->Location = System::Drawing::Point(75, 453);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(465, 37);
			this->label6->TabIndex = 45;
			this->label6->Text = L"to occupy - [ˈɒk.jə.paɪ] - займати";
			// 
			// button6
			// 
			this->button6->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button6.BackgroundImage")));
			this->button6->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button6->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button6->FlatAppearance->BorderSize = 0;
			this->button6->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button6->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button6->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button6->Location = System::Drawing::Point(507, 458);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(101, 32);
			this->button6->TabIndex = 44;
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &Dictionary::button6_Click);
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label7->Location = System::Drawing::Point(75, 381);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(428, 37);
			this->label7->TabIndex = 43;
			this->label7->Text = L"density - [ˈden.sɪ.ti] - щільність";
			// 
			// button7
			// 
			this->button7->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button7.BackgroundImage")));
			this->button7->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button7->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button7->FlatAppearance->BorderSize = 0;
			this->button7->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button7->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button7->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button7->Location = System::Drawing::Point(470, 386);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(101, 32);
			this->button7->TabIndex = 42;
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &Dictionary::button7_Click);
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label8->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label8->Location = System::Drawing::Point(75, 745);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(495, 37);
			this->label8->TabIndex = 53;
			this->label8->Text = L"duplicate - [ˈdʒuː.plɪ.kət] - дублікат";
			// 
			// button8
			// 
			this->button8->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button8.BackgroundImage")));
			this->button8->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button8->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button8->FlatAppearance->BorderSize = 0;
			this->button8->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button8->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button8->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button8->Location = System::Drawing::Point(537, 750);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(101, 32);
			this->button8->TabIndex = 52;
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &Dictionary::button8_Click);
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label9->Location = System::Drawing::Point(75, 673);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(569, 37);
			this->label9->TabIndex = 51;
			this->label9->Text = L"recordable - [ɹɪˈkɔɹdəbəɫ] - записуваний";
			// 
			// button9
			// 
			this->button9->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button9.BackgroundImage")));
			this->button9->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button9->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button9->FlatAppearance->BorderSize = 0;
			this->button9->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button9->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button9->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button9->Location = System::Drawing::Point(611, 677);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(101, 32);
			this->button9->TabIndex = 50;
			this->button9->UseVisualStyleBackColor = true;
			this->button9->Click += gcnew System::EventHandler(this, &Dictionary::button9_Click);
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label10->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label10->Location = System::Drawing::Point(75, 598);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(547, 37);
			this->label10->TabIndex = 49;
			this->label10->Text = L"furthermore - [ˌfɜː.ðəˈmɔːr] - крім того";
			// 
			// button10
			// 
			this->button10->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button10.BackgroundImage")));
			this->button10->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button10->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button10->FlatAppearance->BorderSize = 0;
			this->button10->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button10->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button10->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button10->Location = System::Drawing::Point(589, 602);
			this->button10->Name = L"button10";
			this->button10->Size = System::Drawing::Size(101, 32);
			this->button10->TabIndex = 48;
			this->button10->UseVisualStyleBackColor = true;
			this->button10->Click += gcnew System::EventHandler(this, &Dictionary::button10_Click);
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label11->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label11->Location = System::Drawing::Point(899, 741);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(496, 37);
			this->label11->TabIndex = 71;
			this->label11->Text = L"encoded - [ɪnˈkəʊd] - закодований";
			// 
			// button11
			// 
			this->button11->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button11.BackgroundImage")));
			this->button11->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button11->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button11->FlatAppearance->BorderSize = 0;
			this->button11->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button11->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button11->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button11->Location = System::Drawing::Point(1362, 746);
			this->button11->Name = L"button11";
			this->button11->Size = System::Drawing::Size(101, 32);
			this->button11->TabIndex = 70;
			this->button11->UseVisualStyleBackColor = true;
			this->button11->Click += gcnew System::EventHandler(this, &Dictionary::button11_Click);
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label12->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label12->Location = System::Drawing::Point(899, 667);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(358, 37);
			this->label12->TabIndex = 69;
			this->label12->Text = L"to erase - [ɪˈreɪz] - стерти";
			// 
			// button12
			// 
			this->button12->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button12.BackgroundImage")));
			this->button12->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button12->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button12->FlatAppearance->BorderSize = 0;
			this->button12->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button12->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button12->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button12->Location = System::Drawing::Point(1223, 672);
			this->button12->Name = L"button12";
			this->button12->Size = System::Drawing::Size(101, 32);
			this->button12->TabIndex = 68;
			this->button12->UseVisualStyleBackColor = true;
			this->button12->Click += gcnew System::EventHandler(this, &Dictionary::button12_Click);
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label13->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label13->Location = System::Drawing::Point(899, 595);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(532, 37);
			this->label13->TabIndex = 67;
			this->label13->Text = L"affordable - [əˈfɔː.də.bəl] - доступний";
			// 
			// button13
			// 
			this->button13->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button13.BackgroundImage")));
			this->button13->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button13->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button13->FlatAppearance->BorderSize = 0;
			this->button13->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button13->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button13->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button13->Location = System::Drawing::Point(1397, 600);
			this->button13->Name = L"button13";
			this->button13->Size = System::Drawing::Size(101, 32);
			this->button13->TabIndex = 66;
			this->button13->UseVisualStyleBackColor = true;
			this->button13->Click += gcnew System::EventHandler(this, &Dictionary::button13_Click);
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label14->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label14->Location = System::Drawing::Point(899, 523);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(406, 37);
			this->label14->TabIndex = 65;
			this->label14->Text = L"whereas - [weərˈæz] - тоді як";
			// 
			// button14
			// 
			this->button14->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button14.BackgroundImage")));
			this->button14->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button14->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button14->FlatAppearance->BorderSize = 0;
			this->button14->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button14->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button14->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button14->Location = System::Drawing::Point(1271, 528);
			this->button14->Name = L"button14";
			this->button14->Size = System::Drawing::Size(101, 32);
			this->button14->TabIndex = 64;
			this->button14->UseVisualStyleBackColor = true;
			this->button14->Click += gcnew System::EventHandler(this, &Dictionary::button14_Click);
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label15->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label15->Location = System::Drawing::Point(899, 449);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(431, 37);
			this->label15->TabIndex = 63;
			this->label15->Text = L"stable - [ˈsteɪ.bəl] - стабільний";
			// 
			// button15
			// 
			this->button15->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button15.BackgroundImage")));
			this->button15->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button15->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button15->FlatAppearance->BorderSize = 0;
			this->button15->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button15->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button15->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button15->Location = System::Drawing::Point(1296, 454);
			this->button15->Name = L"button15";
			this->button15->Size = System::Drawing::Size(101, 32);
			this->button15->TabIndex = 62;
			this->button15->UseVisualStyleBackColor = true;
			this->button15->Click += gcnew System::EventHandler(this, &Dictionary::button15_Click);
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label16->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label16->Location = System::Drawing::Point(898, 377);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(540, 37);
			this->label16->TabIndex = 61;
			this->label16->Text = L"to resemble - [rɪˈzem.bəl] - нагадувати";
			// 
			// button16
			// 
			this->button16->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button16.BackgroundImage")));
			this->button16->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button16->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button16->FlatAppearance->BorderSize = 0;
			this->button16->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button16->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button16->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button16->Location = System::Drawing::Point(1405, 382);
			this->button16->Name = L"button16";
			this->button16->Size = System::Drawing::Size(101, 32);
			this->button16->TabIndex = 60;
			this->button16->UseVisualStyleBackColor = true;
			this->button16->Click += gcnew System::EventHandler(this, &Dictionary::button16_Click);
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label17->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label17->Location = System::Drawing::Point(899, 303);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(336, 37);
			this->label17->TabIndex = 59;
			this->label17->Text = L"beam - [biːm] - промінь";
			// 
			// button17
			// 
			this->button17->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button17.BackgroundImage")));
			this->button17->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button17->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button17->FlatAppearance->BorderSize = 0;
			this->button17->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button17->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button17->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button17->Location = System::Drawing::Point(1201, 308);
			this->button17->Name = L"button17";
			this->button17->Size = System::Drawing::Size(101, 32);
			this->button17->TabIndex = 58;
			this->button17->UseVisualStyleBackColor = true;
			this->button17->Click += gcnew System::EventHandler(this, &Dictionary::button17_Click);
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label18->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label18->Location = System::Drawing::Point(899, 229);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(296, 37);
			this->label18->TabIndex = 57;
			this->label18->Text = L"hence - [hens] - отже";
			// 
			// button18
			// 
			this->button18->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button18.BackgroundImage")));
			this->button18->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button18->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button18->FlatAppearance->BorderSize = 0;
			this->button18->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button18->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button18->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button18->Location = System::Drawing::Point(1162, 233);
			this->button18->Name = L"button18";
			this->button18->Size = System::Drawing::Size(101, 32);
			this->button18->TabIndex = 56;
			this->button18->UseVisualStyleBackColor = true;
			this->button18->Click += gcnew System::EventHandler(this, &Dictionary::button18_Click);
			// 
			// label19
			// 
			this->label19->AutoSize = true;
			this->label19->Font = (gcnew System::Drawing::Font(L"Leelawadee UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label19->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(17)), static_cast<System::Int32>(static_cast<System::Byte>(126)),
				static_cast<System::Int32>(static_cast<System::Byte>(250)));
			this->label19->Location = System::Drawing::Point(898, 157);
			this->label19->Name = L"label19";
			this->label19->Size = System::Drawing::Size(567, 37);
			this->label19->TabIndex = 55;
			this->label19->Text = L"rewritable - [rʌɪtəbl] - перезаписуваний";
			// 
			// button19
			// 
			this->button19->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button19.BackgroundImage")));
			this->button19->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button19->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button19->FlatAppearance->BorderSize = 0;
			this->button19->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Transparent;
			this->button19->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button19->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button19->Location = System::Drawing::Point(1432, 160);
			this->button19->Name = L"button19";
			this->button19->Size = System::Drawing::Size(101, 32);
			this->button19->TabIndex = 54;
			this->button19->UseVisualStyleBackColor = true;
			this->button19->Click += gcnew System::EventHandler(this, &Dictionary::button19_Click);
			// 
			// pictureBox15
			// 
			this->pictureBox15->BackColor = System::Drawing::Color::White;
			this->pictureBox15->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox15.Image")));
			this->pictureBox15->Location = System::Drawing::Point(-50, 545);
			this->pictureBox15->Name = L"pictureBox15";
			this->pictureBox15->Size = System::Drawing::Size(86, 70);
			this->pictureBox15->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox15->TabIndex = 80;
			this->pictureBox15->TabStop = false;
			// 
			// pictureBox14
			// 
			this->pictureBox14->BackColor = System::Drawing::Color::White;
			this->pictureBox14->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox14.Image")));
			this->pictureBox14->Location = System::Drawing::Point(1540, 647);
			this->pictureBox14->Name = L"pictureBox14";
			this->pictureBox14->Size = System::Drawing::Size(86, 70);
			this->pictureBox14->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox14->TabIndex = 79;
			this->pictureBox14->TabStop = false;
			// 
			// pictureBox13
			// 
			this->pictureBox13->BackColor = System::Drawing::Color::White;
			this->pictureBox13->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox13.Image")));
			this->pictureBox13->Location = System::Drawing::Point(646, 800);
			this->pictureBox13->Name = L"pictureBox13";
			this->pictureBox13->Size = System::Drawing::Size(170, 121);
			this->pictureBox13->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox13->TabIndex = 78;
			this->pictureBox13->TabStop = false;
			// 
			// pictureBox11
			// 
			this->pictureBox11->BackColor = System::Drawing::Color::White;
			this->pictureBox11->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox11.Image")));
			this->pictureBox11->Location = System::Drawing::Point(738, 271);
			this->pictureBox11->Name = L"pictureBox11";
			this->pictureBox11->Size = System::Drawing::Size(78, 93);
			this->pictureBox11->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox11->TabIndex = 77;
			this->pictureBox11->TabStop = false;
			// 
			// pictureBox10
			// 
			this->pictureBox10->BackColor = System::Drawing::Color::White;
			this->pictureBox10->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox10.Image")));
			this->pictureBox10->Location = System::Drawing::Point(1562, 189);
			this->pictureBox10->Name = L"pictureBox10";
			this->pictureBox10->Size = System::Drawing::Size(64, 69);
			this->pictureBox10->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox10->TabIndex = 76;
			this->pictureBox10->TabStop = false;
			// 
			// pictureBox9
			// 
			this->pictureBox9->BackColor = System::Drawing::Color::White;
			this->pictureBox9->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox9.Image")));
			this->pictureBox9->Location = System::Drawing::Point(-14, 828);
			this->pictureBox9->Name = L"pictureBox9";
			this->pictureBox9->Size = System::Drawing::Size(101, 106);
			this->pictureBox9->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox9->TabIndex = 75;
			this->pictureBox9->TabStop = false;
			// 
			// pictureBox6
			// 
			this->pictureBox6->BackColor = System::Drawing::Color::White;
			this->pictureBox6->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox6.Image")));
			this->pictureBox6->Location = System::Drawing::Point(1288, -53);
			this->pictureBox6->Name = L"pictureBox6";
			this->pictureBox6->Size = System::Drawing::Size(78, 93);
			this->pictureBox6->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox6->TabIndex = 74;
			this->pictureBox6->TabStop = false;
			// 
			// pictureBox5
			// 
			this->pictureBox5->BackColor = System::Drawing::Color::White;
			this->pictureBox5->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox5.Image")));
			this->pictureBox5->Location = System::Drawing::Point(1223, 800);
			this->pictureBox5->Name = L"pictureBox5";
			this->pictureBox5->Size = System::Drawing::Size(155, 138);
			this->pictureBox5->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox5->TabIndex = 73;
			this->pictureBox5->TabStop = false;
			// 
			// pictureBox8
			// 
			this->pictureBox8->BackColor = System::Drawing::Color::White;
			this->pictureBox8->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox8.Image")));
			this->pictureBox8->Location = System::Drawing::Point(198, -37);
			this->pictureBox8->Name = L"pictureBox8";
			this->pictureBox8->Size = System::Drawing::Size(101, 77);
			this->pictureBox8->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox8->TabIndex = 72;
			this->pictureBox8->TabStop = false;
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::Color::White;
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(733, 514);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(51, 77);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox1->TabIndex = 81;
			this->pictureBox1->TabStop = false;
			// 
			// pictureBox2
			// 
			this->pictureBox2->BackColor = System::Drawing::Color::White;
			this->pictureBox2->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox2.Image")));
			this->pictureBox2->Location = System::Drawing::Point(-28, 121);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(51, 77);
			this->pictureBox2->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox2->TabIndex = 82;
			this->pictureBox2->TabStop = false;
			// 
			// Dictionary
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(1584, 861);
			this->Controls->Add(this->pictureBox2);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->pictureBox15);
			this->Controls->Add(this->pictureBox14);
			this->Controls->Add(this->pictureBox13);
			this->Controls->Add(this->pictureBox11);
			this->Controls->Add(this->pictureBox10);
			this->Controls->Add(this->pictureBox9);
			this->Controls->Add(this->pictureBox6);
			this->Controls->Add(this->pictureBox5);
			this->Controls->Add(this->pictureBox8);
			this->Controls->Add(this->label11);
			this->Controls->Add(this->button11);
			this->Controls->Add(this->label12);
			this->Controls->Add(this->button12);
			this->Controls->Add(this->label13);
			this->Controls->Add(this->button13);
			this->Controls->Add(this->label14);
			this->Controls->Add(this->button14);
			this->Controls->Add(this->label15);
			this->Controls->Add(this->button15);
			this->Controls->Add(this->label16);
			this->Controls->Add(this->button16);
			this->Controls->Add(this->label17);
			this->Controls->Add(this->button17);
			this->Controls->Add(this->label18);
			this->Controls->Add(this->button18);
			this->Controls->Add(this->label19);
			this->Controls->Add(this->button19);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->button8);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->button9);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->button10);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->button7);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->playSoundButton);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->Name = L"Dictionary";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Dictionary";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox15))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox14))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox13))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox11))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox10))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox9))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox6))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox5))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox8))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	private: System::Void button5_Click(System::Object^ sender, System::EventArgs^ e) {
		this->Close();
	}
	private: System::Void button1_Click_1(System::Object^ sender, System::EventArgs^ e) {
		form1->Show();
		this->Hide();
	}
	private: System::Void playSoundButton_Click(System::Object^ sender, System::EventArgs^ e) {
		this->player->Play();
	}
	private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
		this->player1->Play();
	}
private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
	this->player2->Play();
}
private: System::Void button7_Click(System::Object^ sender, System::EventArgs^ e) {
	this->player3->Play();
}
private: System::Void button6_Click(System::Object^ sender, System::EventArgs^ e) {
	this->player4->Play();
}
private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
	this->player5->Play();
}
private: System::Void button10_Click(System::Object^ sender, System::EventArgs^ e) {
	this->player6->Play();
}
private: System::Void button9_Click(System::Object^ sender, System::EventArgs^ e) {
	this->player7->Play();
}
private: System::Void button8_Click(System::Object^ sender, System::EventArgs^ e) {
	this->player8->Play();
}
private: System::Void button19_Click(System::Object^ sender, System::EventArgs^ e) {
	this->player9->Play();
}
private: System::Void button18_Click(System::Object^ sender, System::EventArgs^ e) {
	this->player10->Play();
}
private: System::Void button17_Click(System::Object^ sender, System::EventArgs^ e) {
	this->player11->Play();
}
private: System::Void button16_Click(System::Object^ sender, System::EventArgs^ e) {
	this->player12->Play();
}
private: System::Void button15_Click(System::Object^ sender, System::EventArgs^ e) {
	this->player13->Play();
}
private: System::Void button14_Click(System::Object^ sender, System::EventArgs^ e) {
	this->player14->Play();
}
private: System::Void button13_Click(System::Object^ sender, System::EventArgs^ e) {
	this->player15->Play();
}
private: System::Void button12_Click(System::Object^ sender, System::EventArgs^ e) {
	this->player16->Play();
}
private: System::Void button11_Click(System::Object^ sender, System::EventArgs^ e) {
	this->player17->Play();
}
};
}
