#include "Main.h"

[System::STAThread]
int main() {
	System::Windows::Forms::Application::EnableVisualStyles();
	System::Windows::Forms::Application::SetCompatibleTextRenderingDefault(false);
	CourseWork::Main main;
	System::Windows::Forms::Application::Run(% main);

	return 0;
}

